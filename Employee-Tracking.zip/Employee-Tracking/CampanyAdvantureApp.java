import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

public class CampanyAdvantureApp extends Application{

    private TextField FNameField;
    private TextField LNameField;
    private TextField ageField;
    private TextField milesField;
    private TextField rateField;

    private label headerLabel;
    private TextField storyArea;
    private VBox choicesBox;

    private Employee employee;
    private StoryNode[] rootOptions;
    
    @Override
    public void start(Stage stage) {
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));

        root.setCenter(buildSetupPane(root));

        Scene scene = new Scene(root, 600, 400);
        stage.setTitle("Company Adventure");
        stage.setScene(scene);
        stage.show();

        private VBox buildSetupPane(BorderPane root) {
            VBox box = new VBox(10);
            box.setPadding(new Insets(10));

            Label title = new Label("Enter Employee Details");
            title.setStyle("-fx-font-size: 16pt; -fx-font-weight: bold;");
            box.getChildren().add(title);
            FNameField = new TextField();
            FNameField.setPromptText("First Name");
            box.getChildren().add(FNameField);
            LNameField = new TextField();
            LNameField.setPromptText("Last Name");
            box.getChildren().add(LNameField);
            ageField = new TextField();
            ageField.setPromptText("Age");
            box.getChildren().add(ageField);
            milesField = new TextField();
            milesField.setPromptText("Miles to Work");
            box.getChildren().add(milesField);
            rateField = new TextField();
            rateField.setPromptText("Hourly Rate");
            box.getChildren().add(rateField);

            Button startButton = new Button("Start Adventure");
            label errorLabel = new label();
            errorLabel.setStyle("-fx-text-fill: red;");

            startButton.setOnAction(e ->{
                if (createEmployeeFromFields(errorLabel)){
                    showAdventureUI(root);
                }
            });
            box.getChildren().addAll(title, 
                new label("First name:"), fNameField, 
                    new label("Last name:"), lNameField,
                    new label("Age:"), ageField,
                    new label("Miles driven daily:"), milesField,
                    new label("Hourly rate:"), rateField,
                    startButton, errorLabel);
            
            return box;
        }

        public boolean createEmployeeFromFields(label errorLabel) {
            String fName = FNameField.getText().trim();
            String lName = LNameField.getText().trim();
            String ageText = ageField.getText().trim();
            String milesText = milesField.getText().trim();
            String rateText = rateField.getText().trim();

            if (fName.isEmpty() || lName.isEmpty() || ageText.isEmpty() ||
                milesText.isEmpty() || rateText.isEmpty()) {
                errorLabel.setText("All fields must be filled out.");
                return false;
            }
              int age, miles, rate;
            try {
                age = Integer.parseInt(ageText);
                miles = Integer.parseInt(milesText);
                rate = Integer.parseInt(rateText);
            }
            catch (NumberFormatException ex) {

                errorLabel.setText("Age, Miles, and Rate must be valid numbers.");
                return false;
            }
            if (age < 19 || age > 120) {
                errorLabel.setText("Age must be between 19 and 120.");
                return false;
            }
            if (miles < 1 || miles > 500) {
                errorLabel.setText("Miles must be between 1 and 500.");
                return false;
            }
            if (rate < 1 || rate > 200) {
                errorLabel.setText("Rate must be between 1 and 200.");
                return false;
            }

            int adjustedMiles = StoryEngine.calculateMiles(miles);
            int punchIn = 9;
            int punchOut = 17;
            int totalSalary = StoryEngine.computeSalary(punchIn, punchOut, rate);
            int numEmployees = 100;

            String proPossAdj = "their";
            String proSubj = "they";
            String proObj = "them";
            String address = "123 Main St";
            boolean choose = true;

            employee = new Employee(fName, lName, proPossAdj, proSubj, proObj,
                address, choose, age, adjustedMiles, punchIn, punchOut, rate,
                totalSalary, numEmployees);
            
                rootOptions = StoryEngine.buildStoryOptions();
                errorLabel.setText("");
                return true;
        }

    private void showAdventureUI(BorderPane root) {
        headerLabel = new label("Company Adventure Story - " + employee.getFullName());
        headerLabel.setStyle("-fx-font-size: 16pt; -fx-font-weight: bold;");
        root.setTop(headerLabel);

        storyArea = new TextArea();
        storyArea.setEditable(false);
        storyArea.setWrapText(true);
        root.setCenter(storyArea);

        choicesBox = new VBox(10);
        choicesBox.setPadding(new Insets(10));
        root.setBottom(choicesBox);

        String[] company = {"Marketing", "Finance", "Human Resources", "Customer Service", "Training", "Recruiting"};

        storyArea.appendText("\n Company Adventure Story \n");
        storyArea.appendText(employee.getFullName() + " has been a loyal member of our company.\n");
        storyArea.appendText(employee.getPossAdj() + " role is in the " + company[0] + ", "
                + company[3] + ", " + company[5] + " department.\n");
        storyArea.appendText(employee.getSubj() + " drives " + employee.getMiles()
                + " miles each day and earns $" + employee.getTotalSalary() + " per day.\n\n");

        showRootChoices();

    }
    private void showRootChoices() {
        storyArea.appendText("\nWhat will you do today?\n");
        choicesBox.getChildren().clear();

        for (StoryNode node : rootOptions) {
            Button btn = new Button(node.getTitle());
            btn.setMaxWidth(Double.MAX_VALUE);
            btn.setOnAction(e -> playNode(node));
            choicesBox.getChildren().add(btn);{

        }
    }
    private void playNode(StoryNode node) {
        storyArea.appendText("\nYou chose to: " + node.getTitle() + "\n");
        storyArea.appendText(node.getSceneText(employee) + "\n");
        
        StoryNode[] nextNodes = node.getNextNodes();
        choicesBox.getChildren().clear();

        if (nextNodes.length == 0) {
            endSummary();
        } else {
            storyArea.appendText("\nNext options:\n");
            for (StoryNode nextNode : nextNodes) {
                Button btn = new Button(nextNode.getTitle());
                btn.setMaxWidth(Double.MAX_VALUE);
                btn.setOnAction(e -> playNode(nextNode));
                choicesBox.getChildren().add(btn);
            }
        }
    }
            return;
        }
    }
}
