public class FixIssueNode extends StoryNode {

    public FixIssueNode(String title, StoryNode[] nextNodes) {
        super(title, nextNodes);
    }

    @Override
    public void play(Employee emp) {
        System.out.println("You solve a critical system issue! "
                + "The IT team celebrates your quick thinking.");
    }
}

